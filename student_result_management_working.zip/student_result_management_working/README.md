# Student Result Management System — Working Dashboard

This is a functional local dashboard with student add/edit/delete, marks, automatic totals/percentage/grade/pass-fail calculations, search, and graphical charts.

## Run in VS Code on Windows

1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run these commands one by one:

```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

5. Open http://127.0.0.1:5000 in your browser.

If PowerShell blocks environment activation, use:

```powershell
py -m pip install -r requirements.txt
py app.py
```

## Features
- Add student records and subject marks
- Persistent local SQLite database (`students.db` is created automatically)
- Edit and delete student records
- Search by roll number, student name, or department
- Automatic total, percentage, grade, and pass/fail calculation
- Grade distribution chart, pass/fail doughnut chart, and top student percentage chart
- Dashboard summary cards update from saved records

## Important cloud note
This version works locally and saves records to SQLite. It is **not yet connected to Firebase Cloud Firestore**. The Firebase integration can be added after you confirm this version runs correctly. For a Cloud Computing submission, connect Firestore and deploy the app before claiming it is cloud-connected.

The charts use Chart.js from a CDN, so an internet connection is required for charts to render.
