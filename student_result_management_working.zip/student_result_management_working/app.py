from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-demo-secret-before-deployment"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "students.db"

SUBJECTS = ["Python", "Database Management", "Cloud Computing", "Mathematics", "Computer Networks"]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                roll_no TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                department TEXT NOT NULL,
                year TEXT NOT NULL,
                python REAL NOT NULL DEFAULT 0,
                dbms REAL NOT NULL DEFAULT 0,
                cloud REAL NOT NULL DEFAULT 0,
                maths REAL NOT NULL DEFAULT 0,
                cn REAL NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

def grade_for(percentage):
    if percentage >= 90: return "A+"
    if percentage >= 80: return "A"
    if percentage >= 70: return "B+"
    if percentage >= 60: return "B"
    if percentage >= 50: return "C"
    if percentage >= 40: return "D"
    return "F"

def serialize_student(row):
    student = dict(row)
    keys = ["python", "dbms", "cloud", "maths", "cn"]
    total = sum(float(student[k]) for k in keys)
    percentage = total / len(keys)
    student["total"] = total
    student["percentage"] = round(percentage, 2)
    student["grade"] = grade_for(percentage)
    student["status"] = "Pass" if all(float(student[k]) >= 35 for k in keys) else "Fail"
    return student

@app.route("/")
def dashboard():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM students ORDER BY id DESC").fetchall()
    students = [serialize_student(row) for row in rows]
    count = len(students)
    published = sum(1 for s in students if s["status"] in ("Pass", "Fail"))
    average = round(sum(s["percentage"] for s in students) / count, 1) if count else 0
    pass_count = sum(1 for s in students if s["status"] == "Pass")
    fail_count = count - pass_count
    grade_counts = {g: sum(1 for s in students if s["grade"] == g) for g in ["A+", "A", "B+", "B", "C", "D", "F"]}
    chart_students = sorted(students, key=lambda s: s["percentage"], reverse=True)[:7]
    chart_data = {
        "gradeLabels": list(grade_counts.keys()),
        "gradeValues": list(grade_counts.values()),
        "passFail": [pass_count, fail_count],
        "topNames": [s["name"] for s in chart_students],
        "topPercentages": [s["percentage"] for s in chart_students],
    }
    return render_template("dashboard.html", students=students, count=count, published=published,
                           average=average, pass_count=pass_count, fail_count=fail_count,
                           chart_data=chart_data)

@app.route("/students/add", methods=["POST"])
def add_student():
    fields = {
        "roll_no": request.form.get("roll_no", "").strip(),
        "name": request.form.get("name", "").strip(),
        "department": request.form.get("department", "").strip(),
        "year": request.form.get("year", "").strip(),
    }
    mark_fields = {"python": "python", "dbms": "dbms", "cloud": "cloud", "maths": "maths", "cn": "cn"}
    marks = {}
    try:
        for form_key, db_key in mark_fields.items():
            value = float(request.form.get(form_key, "0"))
            if not 0 <= value <= 100:
                raise ValueError("Marks must be between 0 and 100.")
            marks[db_key] = value
    except ValueError:
        flash("Please enter valid marks between 0 and 100 for every subject.", "error")
        return redirect(url_for("dashboard") + "#add-student")
    if not all(fields.values()):
        flash("Please fill in all student details.", "error")
        return redirect(url_for("dashboard") + "#add-student")
    try:
        with get_db() as conn:
            conn.execute("""
                INSERT INTO students (roll_no, name, department, year, python, dbms, cloud, maths, cn)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (fields["roll_no"], fields["name"], fields["department"], fields["year"],
                  marks["python"], marks["dbms"], marks["cloud"], marks["maths"], marks["cn"]))
        flash(f"Student {fields['name']} added successfully.", "success")
    except sqlite3.IntegrityError:
        flash("That roll number already exists. Use a unique roll number.", "error")
    return redirect(url_for("dashboard") + "#students")

@app.route("/students/<int:student_id>/delete", methods=["POST"])
def delete_student(student_id):
    with get_db() as conn:
        conn.execute("DELETE FROM students WHERE id = ?", (student_id,))
    flash("Student record deleted.", "success")
    return redirect(url_for("dashboard") + "#students")

@app.route("/students/<int:student_id>/edit", methods=["POST"])
def edit_student(student_id):
    name = request.form.get("name", "").strip()
    department = request.form.get("department", "").strip()
    year = request.form.get("year", "").strip()
    keys = ["python", "dbms", "cloud", "maths", "cn"]
    try:
        marks = [float(request.form.get(k, "0")) for k in keys]
        if any(m < 0 or m > 100 for m in marks):
            raise ValueError()
        if not name or not department or not year:
            raise ValueError()
    except ValueError:
        flash("Check the student details and marks (0–100).", "error")
        return redirect(url_for("dashboard") + "#students")
    with get_db() as conn:
        conn.execute("""UPDATE students SET name=?, department=?, year=?, python=?, dbms=?, cloud=?, maths=?, cn=? WHERE id=?""",
                     (name, department, year, *marks, student_id))
    flash("Student record updated.", "success")
    return redirect(url_for("dashboard") + "#students")

@app.route("/health")
def health():
    return jsonify({"status": "ok", "database": "SQLite local database", "records": get_count()})

def get_count():
    with get_db() as conn:
        return conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]

init_db()

if __name__ == "__main__":
    app.run(debug=True)
